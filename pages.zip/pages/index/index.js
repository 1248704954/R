Page({
  data: {
    categoryList: {
      pageone: [{
        name: "视频打卡",
        src: "../../icons/视频打卡.png",
        url: "/pages/search/search"
      }, {
        name: "听见你的声音",
        src: "../../icons/听见你的声音.png",
        url: "/pages/search/search"
      }, {
        name: "期刊",
        src: "../../icons/期刊.png",
        url: "/pages/search/search"
      }, {
        name: "图书",
        src: "../../icons/图书.png",
        url: "/pages/search/search"
      }, {
        name: "讲座",
        src: "../../icons/讲座.png",
        url: "/pages/search/search"
      }, {
        name: "工业设计",
        src: "../../icons/工业设计.png",
        url: "/pages/search/search"
      }, {
        name: "英语阅读",
        src: "../../icons/英语阅读.png",
        url: "/pages/search/search"
      }, {
        name: "古典音乐",
        src: "../../icons/古典音乐.png",
        url: "/pages/search/search"
      }],
      
    }
  }
})